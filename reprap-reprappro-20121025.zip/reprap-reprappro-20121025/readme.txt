For details of how to install RepRap on your computer, see:

    http://objects.reprap.org/wiki/Installing_RepRap_on_your_computer

For details of how to use this RepRap Java host software see:

    http://objects.reprap.org/wiki/How_to_use_RepRap_Version_II_Mendel